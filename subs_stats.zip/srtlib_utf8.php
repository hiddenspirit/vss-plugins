<?php

# Internally UTF-8, Windows newlines
class SrtEntry {
    const newline = "\r\n";

    function __construct($num, $start, $stop, $text) {
        $this->num = $num;
        $this->start = $start;
        $this->stop = $stop;
        $this->text = $text;
    }

    function stripped_text() {
        return trim(preg_replace('/<[^>]*>|{[^}]*}/', '', $this->text));
    }

    function duration() {
        return $this->stop - $this->start;
    }

    function reading_speed() {
        if ($this->duration() <= 500) {
            return INF;
        }
        return mb_strlen($this->stripped_text(), 'UTF-8') * 1000 / ($this->duration() - 500);
    }

    function chars_per_second() {
        if ($this->duration() <= 0) {
            return INF;
        }
        return mb_strlen($this->stripped_text(), 'UTF-8') * 1000 / $this->duration();
    }
}

function srt_cmp($a, $b) {
    if ($a->start < $b->start) {
        return -1;
    } elseif ($a->start > $b->start) {
        return 1;
    } elseif ($a->stop < $b->stop) {
        return -1;
    } elseif ($a->stop > $b->stop) {
        return 1;
    } elseif ($a->num < $b->num) {
        return -1;
    } elseif ($a->num > $b->num) {
        return 1;
    } else {
        return 0;
    }
}

function int_int_divide($x, $y) {
    return ($x - ($x % $y)) / $y;
}

function time2hmsms($time) {
    $h = int_int_divide($time, 3600000);
    $ms = $time % 1000;
    $time %= 3600000;
    $m = int_int_divide($time, 60000);
    $time %= 60000;
    $s = int_int_divide($time, 1000);

    return array($h, $m, $s, $ms);
}

function timepair($start, $stop) {
    list($bh, $bm, $bs, $bms) = time2hmsms($start);
    list($eh, $em, $es, $ems) = time2hmsms($stop);
    return sprintf("%02d:%02d:%02d,%03d --> %02d:%02d:%02d,%03d", $bh, $bm, $bs, $bms, $eh, $em, $es, $ems);
}

function read_srt($filepath, $encoding = 'ISO-8859-1') {
    $srt_list = array();

    $in_file = fopen($filepath, 'r');
    if ($in_file === FALSE) {
        return $srt_list;
    }

    $entry = 0;
    $text = '';

    while (!feof($in_file)) {
        $line = trim(fgets($in_file), SrtEntry::newline);

        switch ($entry) {
        case 0:
            if (is_numeric($line)) {
                $num = (int)$line;
                ++$entry;
            }

            break;
        case 1:
            $r = preg_match('/(\d+):(\d+):(\d+)[,.](\d+)\D+(\d+):(\d+):(\d+)[,.](\d+)/', $line, $regs);

            if ($r !== FALSE) {
                $time_pair = $line;
                list($all, $bh, $bm, $bs, $bms, $eh, $em, $es, $ems) = $regs;
                $start = $bh * 3600000 + $bm * 60000 + $bs * 1000 + $bms;
                $stop = $eh * 3600000 + $em * 60000 + $es * 1000 + $ems;
                ++$entry;
            } else {
                $entry = 0;
            }

            break;
        case 2:
            if ($line == '') {
                $text = trim($text, SrtEntry::newline);
                if ($encoding != 'UTF-8') {
                    $text = utf8_encode($text);
                }
                $srt = new SrtEntry($num, $start, $stop, $text);
                $srt_list[] = $srt;
                $entry = 0;
                $text = '';
            } else {
                $text .= $line . SrtEntry::newline;
            }

            break;
        }
    }

    fclose($in_file);

    if ($entry) {
        $text = trim($text, SrtEntry::newline);
        if ($encoding != 'UTF-8') {
            $text = utf8_encode($text);
        }
        $srt = new SrtEntry($num, $start, $stop, $text);
        $srt_list[] = $srt;
    }

    usort($srt_list, srt_cmp);

    return $srt_list;
}

function write_srt($srt_data, $encoding = 'ISO-8859-1') {
    $out = '';
    $num = 0;

    foreach ($srt_data as $sub) {
        $out .= $sub->num . SrtEntry::newline;
        #$out .= ++$num . SrtEntry::newline;
        $out .= timepair($sub->start, $sub->stop) . SrtEntry::newline;
        $out .= ($encoding != 'UTF-8' ? utf8_decode($sub->text) : $sub->text) . SrtEntry::newline . SrtEntry::newline;
    }

    return $out;
}

?>