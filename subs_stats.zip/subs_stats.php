<?php
include_once('srtlib_utf8.php');

$CACHABLE_DOMAINS = array('dl.free.fr', 'www.opensubtitles.org');

function get_domain($url) {
	if (substr($url, 0, 7) != 'http://') {
		return $url;
	}

	$pos = strpos($url, '/', 7);

	if ($pos === FALSE) {
		return $url;
	}

	return substr($url, 7, $pos - 7);
}

function cleanup_dir($dirname, $expire = 2592000) {
	$current = time();
	$last_cleanup_name = $dirname . '/.last_cleanup';

	if (file_exists($last_cleanup_name)) {
		$last_cleanup = (int)file_get_contents($last_cleanup_name);
	} else {
		$last_cleanup = 0;
	}

	if ($current - $last_cleanup < 86400) {
		return;
	}

	foreach (scandir($dirname) as $filename) {
		if ($filename[0] == '.') {
			continue;
		}

		$path = $dirname . '/' . $filename;

		if ($current - filemtime($path) > $expire) {
			unlink($path);
		}
	}

	file_put_contents($last_cleanup_name, $current);
}

function echo_form($msg = '', $allow_url = FALSE) {
		echo
'<script type="text/javascript" language="JavaScript">
<!--
function check() {
	var path = document.stats.file.value;
	var ext = path.substring(path.length - 3, path.length).toLowerCase();
	if(path && ext != "srt") {
		alert("Please select a .srt file.");
		return false;
	} else {
		return true;
	}
}
function setFile() {
	document.stats.method = "POST";
	document.stats.url.value = "";
}
function setUrl() {
	document.stats.method = "GET";
	document.stats.file.value = "";
}
-->
</script>

<h1>Subtitles Statistics</h1>
<form name="stats" enctype="multipart/form-data" action="' . $_SERVER['PHP_SELF'] . '" method="POST" onSubmit="return check();">
Choose a file: <input name="file" type="file" onChange="setFile();" /><br />';

if ($allow_url) {
	echo 'or URL: <input name="url" size="50" onChange="setUrl();" /><br />';
}

echo 'Discard (from-to or num,num,...): <input name="discard" /><br />
Encoding:
<select name="encoding">
<option value="ISO-8859-1">ISO-8859-1</option>
<option value="UTF-8">UTF-8</option>
</select><br /><br />
<input type="submit" />
<input type="reset" />
</form>
<p>Supported format: SubRip (.srt) file</p>';

	if ($msg) {
		echo '<p><b><font color="red">' . $msg . '</font></b></p>';
	}

	exit();
}

function parse_discard($discard) {
	$discard_list = array();

	if ($discard != '') {
		list($from, $to) = explode('-', $discard);

		if ($to !== NULL) {
			for ($i = $from; $i <= $to; ++$i) {
				$discard_list[] = $i;
			}
		} else {
			$discard_list = explode(',', $discard);
		}
	}

	return $discard_list;
}

function append_dom_text($doc, &$node, $name, $text) {
	$element = $doc->createElement($name);
	$element->appendChild($doc->createTextNode($text));
	$node->appendChild($element);
}

function append_dom_stats($doc, &$node, $this_sub) {
	$sub = $doc->createElement('sub');
	$num = $doc->createElement('num');
	$text = $doc->createElement('text');
	$duration = $doc->createElement('duration');
	$rs = $doc->createElement('rs');

	$num->appendChild($doc->createTextNode($this_sub->num));
	$duration->appendChild($doc->createTextNode($this_sub->duration()));
	$rs->appendChild($doc->createTextNode($this_sub->reading_speed()));

	foreach (explode(SrtEntry::newline, $this_sub->stripped_text()) as $l) {
		$line = $doc->createElement('line');
		$line->appendChild($doc->createTextNode($l));
		$text->appendChild($line);
	}

	$sub->appendChild($num);
	$sub->appendChild($text);
	$sub->appendChild($duration);
	$sub->appendChild($rs);

	$node->appendChild($sub);
}

function append_dom_sub_list($doc, &$node, $name, $list) {
	$element = $doc->createElement($name);
	$node->appendChild($element);

	foreach ($list as $sub) {
		append_dom_stats($doc, $element, $sub);
	}
}

function stats_srt($file_location, $filename = NULL, $encoding = 'ISO-8859-1', $discard = '', $cache_id = '') {
	if ($filename === NULL) {
		$filename = $file_location;
	}

	$discard_list = parse_discard($discard);
	$srt_list = read_srt($file_location, $encoding) or echo_form('Can\'t open: ' . $filename);

	$rs_limit_list = array(5, 10, 13, 15, 23, 27, 31, 35);
	$rs_ratings = array('tooSlow', 'slowAcceptable', 'aBitSlow', 'goodSlow', 'perfect', 'goodFast', 'aBitFast', 'fastAcceptable', 'tooFast');
	$max_line_len = 40;

	$rs_count_list = array(0, 0, 0, 0, 0, 0, 0, 0, 0);
	$too_fast_list = array();
	$too_slow_list = array();
	$too_long_line_list = array();
	$discarded_list = array();
	$valid_count = 0;
	$pos = 0;
	$srt_list_len = count($srt_list);
	$rs_limit_list_len = count($rs_limit_list);

#	$min_cps = NULL;
#	$max_cps = NULL;
#	$avg_cps = NULL;
	$sum_cps = 0;

#	$min_rs = NULL;
#	$max_rs = NULL;
#	$avg_rs = NULL;
	$sum_rs = 0;

#	$min_lines = NULL;
#	$max_lines = NULL;
#	$avg_lines = NULL;
	$sum_lines = 0;

#	$min_chars = NULL;
#	$max_chars = NULL;
#	$avg_chars = NULL;
	$sum_chars = 0;
	$total_lines = 0;

#	$min_dur = NULL;
#	$max_dur = NULL;
#	$avg_dur = NULL;
	$sum_dur = 0;

#	$min_blank = NULL;
#	$max_blank = NULL;
#	$avg_blank = NULL;
	$sum_blank = 0;

	$total_text = 0;

	$tooFastSeries = 0;
	$fastAcceptableSeries = 0;
	$aBitFastSeries = 0;
	$intervalSeries = 1000;

	foreach ($srt_list as $current_sub) {
		#$previous_sub = $pos > 0 ? $srt_list[$pos - 1] : NULL;
		$next_sub = $pos < $srt_list_len ? $next_sub = $srt_list[$pos + 1] : NULL;
		$blank = $next_sub ? $next_sub->start - $current_sub->stop : NULL;

		$duration = $current_sub->duration();
		$cps = $current_sub->chars_per_second();
		$rs = $current_sub->reading_speed();
		$stripped_text = $current_sub->stripped_text();

		if ($stripped_text && is_finite($rs) && in_array($current_sub->num, $discard_list) === FALSE) {
			++$valid_count;
			$sum_dur += $duration;

#			$sum_cps += $cps * $duration;
			$sum_cps += $cps;
			if ($min_cps === NULL || $cps < $min_cps)
				$min_cps = $cps;
			if ($max_cps === NULL || $cps > $max_cps)
				$max_cps = $cps;

#			$sum_rs += $rs * $duration;
			$sum_rs += $rs;
			if ($min_rs === NULL || $rs < $min_rs)
				$min_rs = $rs;
			if ($max_rs === NULL || $rs > $max_rs)
				$max_rs = $rs;

			$lines = explode(SrtEntry::newline, $stripped_text);
			$num_lines = count($lines);
			$sum_lines += $num_lines;
			if ($min_lines === NULL || $num_lines < $min_lines)
				$min_lines = $num_lines;
			if ($max_lines === NULL || $num_lines > $max_lines)
				$max_lines = $num_lines;

			$is_too_long_line = FALSE;
			foreach ($lines as $line) {
				$num_chars = mb_strlen($line, 'UTF-8');
				$sum_chars += $num_chars;
				$total_lines += 1;
				if ($num_chars > $max_line_len) {
					$is_too_long_line = TRUE;
				}
				if ($min_chars === NULL || $num_chars < $min_chars)
					$min_chars = $num_chars;
				if ($max_chars === NULL || $num_chars > $max_chars)
					$max_chars = $num_chars;
			}
			if ($is_too_long_line) {
				$too_long_line_list[] = $current_sub;
			}

			if ($min_dur === NULL || $duration < $min_dur)
				$min_dur = $duration;
			if ($max_dur === NULL || $duration > $max_dur)
				$max_dur = $duration;

			if ($blank) {
				$sum_blank += $blank;
				if ($min_blank === NULL || $blank < $min_blank)
					$min_blank = $blank;
				if ($max_blank === NULL || $blank > $max_blank)
					$max_blank = $blank;
			}

			$total_text += mb_strlen($stripped_text, 'UTF-8');

			$n = 0;
			foreach ($rs_limit_list as $rs_limit) {
				if ($rs < $rs_limit) {
					++$rs_count_list[$n];
					break;
				}

				++$n;
			}

			if ($n == $rs_limit_list_len) {
				$too_fast_list[] = $current_sub;
				++$rs_count_list[$n];
			}

			if ($n == 0) {
				$too_slow_list[] = $current_sub;
			}

			if ($next_sub) {
				$interval = $next_sub->start - $current_sub->stop;
				$next_rs = $next_sub->reading_speed();
				if ($interval <= $intervalSeries) {
					if ($rs >= 35 && $next_rs >= 35) {
						++$tooFastSeries;
					} elseif ($rs >= 31 && $next_rs >= 31) {
						++$fastAcceptableSeries;
					} elseif ($rs >= 27 && $next_rs >= 27) {
						++$aBitFastSeries;
					}
				}
			}
		} else {
			$discarded_list[] = $current_sub;
		}

		++$pos;
	}

	$total_count = $pos;

	if ($valid_count > 0) {
#		$avg_cps = $sum_cps / $sum_dur;
#		$avg_rs = $sum_rs / $sum_dur;
		$avg_cps = $sum_cps / $valid_count;
		$avg_rs = $sum_rs / $valid_count;

#		$avg_lines = $sum_lines / $valid_count;
#		$avg_chars = $sum_chars / $total_lines;
#		$avg_dur = $sum_dur / $valid_count;
#		$avg_blank = $sum_blank / $valid_count;

		$doc = new DOMDocument('1.0', 'utf-8');
		$doc->formatOutput = true;

		$pi = new DOMProcessingInstruction('xml-stylesheet', 'type="text/xsl" href="/subs_stats.xsl"');
		$doc->appendChild($pi);

		$root = $doc->createElement('subsStats');
		$doc->appendChild($root);

		append_dom_text($doc, $root, 'name', $filename);

		// if ($file_location == $filename) {
			// $link = $_SERVER['PHP_SELF'] . '?url=' . urlencode($file_location);
			// if ($encoding == 'UTF-8') {
				// $link .= '&encoding=' . $encoding;
			// }
			// if ($discard != '') {
				// $link .= '&discard=' . $discard;
			// }
			// append_dom_text($doc, $root, 'link', $link);
		// }

		if ($cache_id) {
			$link = $_SERVER['PHP_SELF'] . '?cache=' . $cache_id;
			append_dom_text($doc, $root, 'link', $link);
		}

		$stats = $doc->createElement('stats');
		$root->appendChild($stats);

		$i = 0;

		foreach ($rs_ratings as $rating_name) {
			$count = $rs_count_list[$i];
			append_dom_text($doc, $stats, $rating_name, $count);
			++$i;
		}

		append_dom_text($doc, $stats, 'totalCount', $total_count);
		append_dom_text($doc, $stats, 'validCount', $valid_count);

		append_dom_text($doc, $stats, 'minCps', $min_cps);
		append_dom_text($doc, $stats, 'maxCps', $max_cps);
		append_dom_text($doc, $stats, 'avgCps', $avg_cps);

		append_dom_text($doc, $stats, 'minRs', $min_rs);
		append_dom_text($doc, $stats, 'maxRs', $max_rs);
		append_dom_text($doc, $stats, 'avgRs', $avg_rs);

		append_dom_text($doc, $stats, 'maxLinesPerSub', $max_lines);
		append_dom_text($doc, $stats, 'maxCharsPerLine', $max_chars);
		append_dom_text($doc, $stats, 'minDuration', $min_dur);
		append_dom_text($doc, $stats, 'maxDuration', $max_dur);
		append_dom_text($doc, $stats, 'minBlank', $min_blank);
		append_dom_text($doc, $stats, 'tooFastSeries', $tooFastSeries);
		append_dom_text($doc, $stats, 'fastAcceptableSeries', $fastAcceptableSeries);
		append_dom_text($doc, $stats, 'aBitFastSeries', $aBitFastSeries);
		append_dom_text($doc, $stats, 'totalText', $total_text);
		append_dom_text($doc, $stats, 'totalTime', $sum_dur);

		append_dom_sub_list($doc, $root, 'tooFastSubs', $too_fast_list);
		append_dom_sub_list($doc, $root, 'tooSlowSubs', $too_slow_list);
		append_dom_sub_list($doc, $root, 'tooLongLineSubs', $too_long_line_list);
		append_dom_sub_list($doc, $root, 'discardedSubs', $discarded_list);

		return trim($doc->saveXML()); // sometimes, we need to trim some weird characters??
	} else {
		echo_form('Can\'t process: ' . $filename);
	}
}

$cache = $_GET['cache'];

if ($cache) {
	$cache_path = 'cache/' . $cache . '.xml';

	if (file_exists($cache_path)) {
		header('Content-Type: application/xml');
		echo file_get_contents($cache_path);
		touch($cache_path);
		exit();
	}
}

$url = urldecode($_GET['url']);
if (!$url) {
	$url = $_POST['url'];
}

$discard = $_GET['discard'];
if (!$discard) {
	$discard = $_POST['discard'];
}

$encoding = $_GET['encoding'];
if (!$encoding) {
	$encoding = $_POST['encoding'];
}
$encoding = strtoupper($encoding) == 'UTF-8' ? 'UTF-8' : 'ISO-8859-1';

if ($url) {
	/*$headers = get_headers($url, 1);

	if (preg_match('/filename="?(.*)"?/', $headers["Content-Disposition"], $regs)) {
		$filename = trim($regs[1], '"');
	} else {
		$filename = basename($url);
	}*/

	$cache_id = sha1($url . $encoding . $discard);
	$cache_path = 'cache/' . $cache_id . '.xml';

	if (file_exists($cache_path)) {
		if (in_array(get_domain($url), $CACHABLE_DOMAINS)) {
			header('Content-Type: application/xml');
			echo file_get_contents($cache_path);
			exit();
		} else {
			$expire_time = filemtime($cache_path) + 10;
			if (time() <= $expire_time) {
				header('Content-Type: application/xml');
				echo file_get_contents($cache_path);
				exit();
			}
		}
	}

	$xml = stats_srt($url, NULL, $encoding, $discard, $cache_id);
	cleanup_dir('cache');
	file_put_contents($cache_path, $xml);
	header('Content-Type: application/xml');
	echo $xml;
} else {
	$uploaded_file = $_FILES['file'];
	$location = $uploaded_file['tmp_name'];
	$cache_id = sha1($location . $encoding . $discard);
	$cache_path = 'cache/' . $cache_id . '.xml';

	if (is_uploaded_file($location)) {
		$filename = $uploaded_file['name'];
		$xml = stats_srt($location, $filename, $encoding, $discard, $cache_id);
		cleanup_dir('cache');
		file_put_contents($cache_path, $xml);
		header('Content-Type: application/xml');
		echo $xml;
	} else {
		echo_form();
	}
}
?>
