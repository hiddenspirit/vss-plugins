Pack Subfactory.fr

Plus d'info sur les critères de qualité et les normes de synchro Subfactory.fr :
http://www.subfactory.fr/forum.html#thread/31470/1

Dans le répertoire de VisualSubSync (par défaut :
"C:\Program Files\VisualSubSync\"), supprimez le répertoire “jsplugin” existant,
puis décompressez le ZIP (tout écraser). Pour charger un mode 1, 2 ou 3,
allez dans File > Load presets... et choisissez le fichier .ini désiré.

http://nathbot.frox.fr/vss/
